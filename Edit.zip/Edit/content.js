function clickTopEditButton() {
  // ১. সরাসরি CSS Selector দিয়ে চেষ্টা
  let topBtn = document.querySelector('a[href*="edit"], button[class*="edit"], .btn-primary');
  
  // ২. টেক্সট ম্যাচ করে খুঁজে বের করা
  if (!topBtn) {
    const allElements = document.querySelectorAll('a, button, div, span');
    for (let el of allElements) {
      if (el.children.length === 0 && el.textContent.trim() === 'Edit') {
        topBtn = el;
        break; // প্রথম 'Edit' এলিমেন্টটি পেলেই লুপ থামবে (উপরের বাটন)
      }
    }
  }

  // ৩. মাউস ক্লিক ইভেন্ট ট্রিগার করা
  if (topBtn) {
    topBtn.focus();
    topBtn.click();
    
    // JS Framework (like Vue/React) এর জন্য ম্যানুয়াল ক্লিক ইভেন্ট
    const eventOptions = { bubbles: true, cancelable: true, view: window };
    topBtn.dispatchEvent(new MouseEvent('mousedown', eventOptions));
    topBtn.dispatchEvent(new MouseEvent('mouseup', eventOptions));
    topBtn.dispatchEvent(new MouseEvent('click', eventOptions));
    
    console.log("Clicked:", topBtn);
  } else {
    alert("Edit বাটনটি পাওয়া যায়নি! পেজটি ঠিকমত লোড হয়েছে কিনা দেখুন।");
  }
}

// ব্যাকগ্রাউন্ড থেকে মেসেজ আসলে রান হবে
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "click_edit") {
    clickTopEditButton();
  }
});